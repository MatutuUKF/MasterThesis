using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{

    public float rotationSpeed;
    private float xRotation = 0f;

    public Transform[] waypoints;
    public float speed;
    private int currentWaypointIndex = 0;

    public float zoomSpeed = 0.5f;
    public Camera cameraToZoom;

    void Update()
    {

        if (SystemInfo.deviceType == DeviceType.Desktop)
        {

            MouseControll();
        }
        else if (SystemInfo.deviceType == DeviceType.Handheld)
        {


            DisplayControll();
            ZoomControl();
        }

        if (currentWaypointIndex < waypoints.Length)
        {
            Transform targetWaypoint = waypoints[currentWaypointIndex];
            transform.position = Vector3.MoveTowards(transform.position, targetWaypoint.position, speed * Time.deltaTime);

            if (Vector3.Distance(transform.position, targetWaypoint.position) < 0.1f)
            {
                currentWaypointIndex++;
            }
            if (currentWaypointIndex == waypoints.Length && Vector3.Distance(transform.position, targetWaypoint.position) < 0.1f)
            {

                currentWaypointIndex = 0;
            }
        }

        ZoomControl();
    }

    private void ZoomControl()
    {

        if (Input.touchCount == 2)
        {
            Touch touchZero = Input.GetTouch(0);
            Touch touchOne = Input.GetTouch(1);

            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;

            float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

            Camera.main.fieldOfView += deltaMagnitudeDiff * zoomSpeed;

            Camera.main.fieldOfView = Mathf.Clamp(Camera.main.fieldOfView, 0.1f, 179.9f);

        }
    }


    private void DisplayControll()
    {

        
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            float rotationY = touch.deltaPosition.x * rotationSpeed * Time.deltaTime;

            transform.Rotate(0, rotationY, 0, Space.World);
        }
        else
        {

            transform.Rotate(0, -rotationSpeed * Time.deltaTime, 0, Space.World);
        }

    }
    private void MouseControll()
    {
        if (Input.GetMouseButton(1))
        {
            float mouseX = Input.GetAxis("Mouse X") * rotationSpeed * Time.deltaTime;
            float mouseY = Input.GetAxis("Mouse Y") * rotationSpeed * Time.deltaTime;

            xRotation -= mouseY;
            xRotation = Mathf.Clamp(xRotation, -90f, 90f);

            transform.localEulerAngles = new Vector3(xRotation, transform.localEulerAngles.y, 0f);

            transform.Rotate(Vector3.up, mouseX);


        }
        else {


            float mouseX = rotationSpeed * Time.deltaTime;

            transform.localEulerAngles = new Vector3(xRotation, transform.localEulerAngles.y, 0f);

            transform.Rotate(Vector3.up, mouseX);

        }

    }


    public void stopMovement() => speed = 0;
    public void startMovement() => speed = 2;

    public void stopRotating() => rotationSpeed = 0;

    public void startRotating() => rotationSpeed = 60;
}
