using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;



public class CanvasController : MonoBehaviour
{
    [SerializeField] Toggle stopMoving;
    [SerializeField] Toggle stopRotating;
    [SerializeField] RawImage textureUI;
    [SerializeField] TMP_Text textureDetails;
    [SerializeField] GameObject texturePanel;
    public CameraController cameraController;
    private Texture clickedTexture;

    public void StopMovement() {
        
        if (stopMoving.isOn) cameraController.stopMovement();
        else cameraController.startMovement();
        
    }
    public void StopRotating() {
        if (stopRotating.isOn) cameraController.stopRotating();
        else cameraController.startRotating();
    }

    void Update()
    {
        
        if (Input.GetMouseButtonDown(0)) 
        {
            SelectObject(Input.mousePosition);
        }

        
        if (Input.touchCount > 0 && Input.touches[0].phase == TouchPhase.Began)
        {
            SelectObject(Input.touches[0].position);
        }
    }

    void SelectObject(Vector2 screenPosition)
    {
        Ray ray = Camera.main.ScreenPointToRay(screenPosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {

            GameObject selectedObject = hit.transform.gameObject;

            if (selectedObject.GetComponent<TextureChanger>())
            {
                clickedTexture = selectedObject.GetComponent<TextureChanger>().getActualTexture();
                Debug.Log(clickedTexture.name);
                textureUI.texture = clickedTexture;

                int bytesPerPixel = 4;
                float sizeInBytes = clickedTexture.width * clickedTexture.height * bytesPerPixel;
                float sizeInMegabytes = sizeInBytes / (1024f * 1024f);
                textureDetails.text =
                    "\n" + $"Name: {selectedObject.name}" +
                    "\n" + $"Format: {clickedTexture.name}" +
                    "\n" + $"MipMap Count: {clickedTexture.mipmapCount}" +
                    "\n" + $"Estimated Size (MB): {sizeInMegabytes}" +
                    "\n" + $"Width x Height: {clickedTexture.width} x {clickedTexture.height}";

            }
        }
    }

}
