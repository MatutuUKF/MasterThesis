using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ConsolController : MonoBehaviour
{

    public TMP_Text gpu_vram;
    // Update is called once per frame
    void Update()
    {
        gpu_vram.text = SystemInfo.graphicsMemorySize.ToString();
    }
}
