﻿using System.Collections;
using System.Collections.Generic;

namespace UTJ.ProfilerReader.UI
{
    public class LanguageEn : LanguageInterface
    {

        protected override void CreateDictionary() {
        }
    }
}
