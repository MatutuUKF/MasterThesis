﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UTJ.ProfilerReader.UI
{
    public class LanguageJa : LanguageInterface
    {
        protected override void CreateDictionary()
        {
        }
    }
}
