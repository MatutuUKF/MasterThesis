using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GizmoWayPoint : MonoBehaviour
{
    public float explosionRadius = 5.0f;

    void OnDrawGizmosSelected()
    {
        // Display the explosion radius when selected
        Gizmos.color = Color.white;
        Gizmos.DrawWireSphere(transform.position, explosionRadius);
    }
}
