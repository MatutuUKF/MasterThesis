using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Transform[] waypoints;
    private int currentWaypointIndex = 0;


    public float speed = 5.0f;
    public float sensitivity = 2.0f;
    CharacterController characterController;
    public Camera camera;

    public Vector3 rotationPointA = new Vector3(0, 0, 0); 
    public Vector3 rotationPointB = new Vector3(0, 180, 0); 


    private float moveFB, moveLR;
    private float rotX, rotY;

    void Start()
    {
        characterController = GetComponent<CharacterController>();
#if UNITY_STANDALONE

        Cursor.lockState = CursorLockMode.Locked;
#endif
    }

    void Update()
    {
        cameraFollow();


#if UNITY_STANDALONE || UNITY_WEBGL
        // PC Controls
        moveFB = Input.GetAxis("Vertical") * speed;
        moveLR = Input.GetAxis("Horizontal") * speed;
        rotX = Input.GetAxis("Mouse X") * sensitivity;
        rotY -= Input.GetAxis("Mouse Y") * sensitivity;
#elif UNITY_IOS || UNITY_ANDROID
        
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            rotX = touch.deltaPosition.x * sensitivity * Time.deltaTime; 
        }
        else
        {
            rotX = -sensitivity * Time.deltaTime; 
        }
        rotY = Mathf.Clamp(rotY, -90f, 90f); 

#endif

    }


    void cameraFollow() {
        if (currentWaypointIndex < waypoints.Length)
        {
            Transform targetWaypoint = waypoints[currentWaypointIndex];
            transform.position = Vector3.MoveTowards(transform.position, targetWaypoint.position, speed * Time.deltaTime);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, targetWaypoint.rotation, speed * Time.deltaTime);

            if (Vector3.Distance(transform.position, targetWaypoint.position) < 0.1f)
            {
                currentWaypointIndex++;
            }
        }
    }
}
