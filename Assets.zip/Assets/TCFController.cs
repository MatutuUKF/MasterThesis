using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class TCFController : MonoBehaviour
{

    [SerializeField] TMP_Dropdown dropDownMenu;
    TextureChanger[] textureChangers;
    void Start()
    {
        textureChangers = FindObjectsOfType<TextureChanger>();
    }


    public void SwitchTextureCompression()
    {

        int pickedValue = dropDownMenu.value;
        string option = dropDownMenu.options[pickedValue].text;


        foreach (TextureChanger changer in textureChangers)
        {
            changer.ChangeTextures(option);
        }

    }
}
