using UnityEngine;


public class TextureChanger : MonoBehaviour
{
    public Texture2D textureETC8; 
    public Texture2D texturePVRTC4; 
    public Texture2D textureASTC4x4;

    public Texture2D textureETC4;
    public Texture2D texturePVRTC2;
    public Texture2D textureASTC12x12;

    private Texture actualTexture;

    private void Start()
    {
        actualTexture = gameObject.GetComponent<Renderer>().material.mainTexture;
    }

    public void ChangeTextures(string format)
    {
        Texture2D targetTexture = null;
        

#if UNITY_ANDROID
        switch (format)
        {
            case "ASTC_4x4": targetTexture = textureASTC4x4; break;
            case "ASTC_12x12": targetTexture = textureASTC12x12; break;
            case "ETC2_8b": targetTexture = textureETC8; break;
            case "ETC2_4b": targetTexture = textureETC4; break;
            case "PVRTC_4b": targetTexture = texturePVRTC4; break;
            case "PVRTC_2b": targetTexture = texturePVRTC2; break;


        }
#endif
        if (targetTexture != null)
        {

            GameObject model = gameObject;
            Renderer renderer = model.GetComponent<Renderer>();
                if (renderer != null)
                {
                Debug.Log("last step");
                renderer.material.mainTexture = targetTexture;
                }
            
        }
        actualTexture = targetTexture;
    }

    public void setPreprocessedTextures(Texture2D inputTexture, string textureName) {
        
        switch (textureName)
        {
            case "ASTC_4x4": textureASTC4x4 = inputTexture; break;
            case "ASTC_12x12": textureASTC12x12 = inputTexture; break;
            case "ETC2_8b": textureETC8 = inputTexture; break;
            case "ETC2_4b": textureETC4 = inputTexture; break;
            case "PVRTC_4b": texturePVRTC4 = inputTexture; break;
            case "PVRTC_2b": texturePVRTC2 = inputTexture; break;


        }
    }
    public Texture getActualTexture() => actualTexture;
    public void setActualTexture(Texture inputValue) => actualTexture = inputValue;
}