using UnityEditor;
using UnityEngine;
using System.IO;
using UnityEditor;
#if UNITY_EDITOR
public class TexturePreProcessScript
{
    [MenuItem("Custom/Process Textures for Models")]
    static void ProcessTexturesForModels()
    {
        var folders = AssetDatabase.GetSubFolders("Assets/TEST");

        foreach (var folderPath in folders)
        {
            var filePaths = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);
            foreach (var filePath in filePaths)
            {
                if (Path.GetExtension(filePath).ToLower() == ".meta") continue;

                var asset = AssetDatabase.LoadAssetAtPath<Object>(filePath);
                if (asset is GameObject gameObject)
                {
                    ProcessGameObjectTextures(gameObject, folderPath);
                }
            }
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    static void ProcessGameObjectTextures(GameObject gameObject, string folderPath)
    {
        var renderers = gameObject.GetComponentsInChildren<Renderer>();
        foreach (var renderer in renderers)
        {
            foreach (var material in renderer.sharedMaterials)
            {
                var texture = material.mainTexture as Texture2D;
                if (texture != null)
                {
                    string[] formats = new string[] { "ASTC_4x4", "ETC2_8b", "ASTC_12x12", "ETC2_4b", "PVRTC_4b", "PVRTC_2b" };
                    foreach (var format in formats)
                    {
                        DuplicateAndProcessTexture(texture, format, folderPath);
                    }
                }
            }
        }

        AssignTexturesToChangerScript(folderPath, gameObject);
    }

    static void DuplicateAndProcessTexture(Texture2D originalTexture, string newNameSuffix, string folderPath)
    {
        TextureImporterFormat targetFormat = GetTextureFormatForName(newNameSuffix);

        var path = AssetDatabase.GetAssetPath(originalTexture);
        var newPath = Path.Combine(folderPath, newNameSuffix + Path.GetExtension(path));

        if (!File.Exists(newPath))
        {
            AssetDatabase.CopyAsset(path, newPath);
            AssetDatabase.Refresh();
            var newTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(newPath);

            var importer = AssetImporter.GetAtPath(newPath) as TextureImporter;
            if (importer != null)
            {
                importer.textureType = TextureImporterType.Default;

                var androidSettings = importer.GetPlatformTextureSettings("Android");
                androidSettings.overridden = true;
                androidSettings.format = targetFormat;
                importer.SetPlatformTextureSettings(androidSettings);

                var iosSettings = importer.GetPlatformTextureSettings("iPhone");
                iosSettings.overridden = true;
                iosSettings.format = targetFormat; 
                importer.SetPlatformTextureSettings(iosSettings);

                AssetDatabase.ImportAsset(newPath, ImportAssetOptions.ForceUpdate);
            }
        }
    }

    static TextureImporterFormat GetTextureFormatForName(string name)
    {
        switch (name)
        {
            case "ASTC_4x4": return TextureImporterFormat.ASTC_4x4;
            case "ETC2_8b": return TextureImporterFormat.ETC2_RGBA8;
            case "ASTC_12x12": return TextureImporterFormat.ASTC_12x12;
            case "ETC2_4b": return TextureImporterFormat.ETC2_RGB4;
            case "PVRTC_4b": return TextureImporterFormat.PVRTC_RGBA4;
            case "PVRTC_2b": return TextureImporterFormat.PVRTC_RGBA2;
            default: return TextureImporterFormat.Automatic;
        }
    }


    static void AssignTexturesToChangerScript(string folderPath, GameObject model)
    {
        var textureChanger = model.GetComponent<TextureChanger>();
        if (textureChanger == null) return;

        string[] textureNames = { "ETC2_8b", "PVRTC_4b", "ASTC_4x4", "ETC2_4b", "PVRTC_2b", "ASTC_12x12" };
        foreach (var name in textureNames)
        {
            var texture = LoadTextureAtPath(folderPath, name);
            switch (name)
            {
                case "ETC2_8b": textureChanger.textureETC8 = texture; break;
                case "PVRTC_4b": textureChanger.texturePVRTC4 = texture; break;
                case "ASTC_4x4": textureChanger.textureASTC4x4 = texture; break;
                case "ETC2_4b": textureChanger.textureETC4 = texture; break;
                case "PVRTC_2b": textureChanger.texturePVRTC2 = texture; break;
                case "ASTC_12x12": textureChanger.textureASTC12x12 = texture; break;
            }
        }

        EditorUtility.SetDirty(textureChanger);
    }

    static Texture2D LoadTextureAtPath(string folderPath, string textureBaseName)
    {
        string[] fileExtensions = { ".png", ".jpg", ".jpeg" };
        foreach (var extension in fileExtensions)
        {
            var path = Path.Combine(folderPath, textureBaseName + extension);
            var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (texture != null) return texture;
        }
        Debug.LogError("Failed to load texture: " + textureBaseName);
        return null;
    }
}

#endif
